# 1701QCA Making Interaction - Assessment 1 workbook

You will use GitHub to keep track of your progress through the course and also as a process journal to document the making of your projects.

You can fill out the workbook from the GitHub website using markdown language for the documents and they will be turned into web pages for you. See the markdown reference guide here: [https://guides.github.com/features/mastering-markdown/](http://guides.github.com/features/mastering-markdown/)

## Index

### Inventor Kit experiments ###

You can edit this workbook here: [Inventor Kit Experiments](/experiments/experiments.md)


### Assessment 1 replication project ###

You can edit this workbook here: [Replication Project](/replicationproject/replication.md)

